#' This function is depreciated, please use [parseClassFun()]
#' @param ... None
#' @return No return value, depreciated
#' @export
ft_parse<-function(...)
{
  stop(sprintf("This function is depreciated, please use parseClassFun().
               See ?parseClassFun"))
}

