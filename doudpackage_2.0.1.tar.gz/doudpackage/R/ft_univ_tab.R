#' This function is depreciated, please use anaBiv(). [descTab()]
#' @param ... None
#' @return No return value, depreciated
#' @export
ft_desc_tab<-function(...)
{
  stop(sprintf("This function is depreciated, please use descTab(). See ?descTab"))
}
