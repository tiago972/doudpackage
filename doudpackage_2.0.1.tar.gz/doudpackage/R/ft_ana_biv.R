#' This function is depreciated, please use anaBiv(). [anaBiv()]
#' @param ... None
#' @return No return value, depreciated
#' @export
ft_ana_biv<-function(...){
  stop(sprintf("This function is depreciated, please use anaBiv().
               See ?anaBiv"))
}
