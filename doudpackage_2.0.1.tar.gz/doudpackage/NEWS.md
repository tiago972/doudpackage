# doudpackage 2.0.1
* CRAN availability

## Major changes
* Added more than 2 sub-groups
* Choice between normal and non normal variables to use either t.test/Wilcox or AOV/Krusall.wallis

## Minor changes
* Faster implementation (no loop used)
