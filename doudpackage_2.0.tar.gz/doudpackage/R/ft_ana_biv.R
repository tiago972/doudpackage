#' This function is depreciated, please use anaBiv(). [anaBiv()]
#' @param ... None
#' @export
ft_ana_biv<-function(...){
  stop(sprintf("This function is depreciated, please use anaBiv().
               See ?anaBiv"))
}
